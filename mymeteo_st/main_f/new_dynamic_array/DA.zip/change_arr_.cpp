#include <iostream>
#include "change_arr_.h"

using namespace changeable_array;

void Array::PushBack(int x, int y)
{
    ArrNode tmp(x,y);
    std::shared_ptr<ArrNode> tmp_{std::make_shared<ArrNode> (tmp)};
    tmp_->SetBackLink(&array_);
    tmp_->SetForwardLink(nullptr);
    array_.SetForwardLink(&tmp);
    array_ = tmp;    
}

int Array::GetCoord(bool x = true) const
{
    return array_.GetCoord_(x);
};

int Array::GetFirstCoord(bool x = true)
{
    return (array_.GetFirst()->GetCoord_(x));
};
